# -*- coding: utf-8 -*-

from odoo import fields, models


class ResUsers(models.Model):
    _inherit = "res.users"

    ddco_office_id = fields.Many2one(
        "doorandoor.commercial.office", string="Commercial Office", ondelete="restrict",
        domain="[('company_id', 'in', company_ids)]",
        help="La oficina comercial define el impuesto aplicado a las ventas de este vendedor.",
    )
