# -*- coding: utf-8 -*-
{
    "name": "DoorAndDoor Commercial Offices and Tax",
    "version": "18.0.1.0.0",
    "category": "Accounting",
    "summary": "Define oficinas comerciales por vendedor y aplica su impuesto a ventas y facturas",
    "description": """
DoorAndDoor Commercial Offices and Tax
======================================

Una sola compañía puede operar varias oficinas comerciales. Cada vendedor se
asocia a una oficina y cada oficina define su dirección, teléfono y tasa de
venta. La oficina se copia y conserva en cotizaciones y facturas para aplicar
el impuesto correspondiente y mantener trazabilidad documental.
""",
    "author": "DoorAndDoor",
    "license": "LGPL-3",
    "depends": ["sale_management", "account", "doorandoor_tax_state", "doorandoor_sales_new"],
    "data": [
        "security/ir.model.access.csv",
        "views/commercial_office_views.xml",
        "views/res_users_views.xml",
        "views/sale_account_views.xml",
    ],
    "installable": True,
    "application": False,
}
